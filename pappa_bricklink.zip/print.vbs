' Test:  wscript print.vbs "labels/send_to_address2.lbx" "Johan Yngman" "Hammarögatan 7" "12340 Stockholm"
'<SCRIPT LANGUAGE="VBScript">

	set Args = Wscript.Arguments
	label_template = Args(0)
	full_address = Args(1)
	action = Args(2)

	DoPrint(label_template)
	
	'Function Printed(status, value)
	'	MsgBox ("Callback")
	'    If (status = 0) Then
	'        MsgBox ("Printed!")
	'    Else
	'        MsgBox ("Error!")
	'    End If
	'End Function

    Sub DoPrint(strFilePath)
		Set ObjDoc = CreateObject("bpac.Document")
		bRet = ObjDoc.Open(strFilePath)
		action_export = StrComp(action, "export", vbTextCompare)

		If (bRet <> False) Then
			ObjDoc.GetObject("full_address").Text = full_address
			ObjDoc.Export 4, "preview.bmp", 96

			if(action_export = 0) Then
				ObjDoc.Export 1, "send_to.lbx", 96
			Else
				'ObjDoc.SetPrintedCallback GetRef("Printed")
				test = ObjDoc.SetPrinter("Brother QL-800", True)
				ObjDoc.SetMediaByName ObjDoc.Printer.GetMediaName(), True
				ObjDoc.StartPrint "", bpoDefault
				ObjDoc.PrintOut 1, "0"
				ObjDoc.EndPrint
				ObjDoc.Close
			End If
		Else
			Wscript.Echo "Could not open " & label_template
		End If
		
		Set ObjDoc = Nothing
	End Sub