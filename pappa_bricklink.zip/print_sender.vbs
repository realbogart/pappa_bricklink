'<SCRIPT LANGUAGE="VBScript">

	set Args = Wscript.Arguments
	order_id = Args(0)

	DoPrint("labels/sender.lbx")

    Sub DoPrint(strFilePath)
		Set ObjDoc = CreateObject("bpac.Document")
		bRet = ObjDoc.Open(strFilePath)
		
		If (bRet <> False) Then
			On Error Resume Next
			ObjDoc.GetObject("order_id").text = order_id
			ObjDoc.Export 4, "preview_sender.bmp", 96
			test = ObjDoc.SetPrinter("Brother QL-800", True)
			ObjDoc.SetMediaByName ObjDoc.Printer.GetMediaName(), True
			ObjDoc.StartPrint "", bpoDefault
			ObjDoc.PrintOut 1, "0"
			ObjDoc.EndPrint
			ObjDoc.Close
		Else
			Wscript.Echo "Could not open " & strFilePath
		End If
		
		Set ObjDoc = Nothing
	End Sub